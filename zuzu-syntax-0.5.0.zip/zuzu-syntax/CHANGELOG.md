# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project roughly adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 0.5.0 - 2026-06-18

### Changed

- Package the current VS Code grammar for the ZuzuScript 0.5.0 release cycle.

## 0.1.1 - 2026-05-29

### Added

- Highlight chain operators, the `^^` chain placeholder, argument spread, and declaration-unpacking syntax.
- Highlight current runtime globals, built-in classes, binary strings, regexp literals, and interpolated regexp/template content.

## 0.1.0 - 2026-05-11

*First release.*
